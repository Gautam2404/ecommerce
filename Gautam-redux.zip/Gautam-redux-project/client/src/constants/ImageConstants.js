const IMAGE_SIZES = {
  LARGE: 't300x300',
  XLARGE: 't500x500',
};

export default IMAGE_SIZES;
